#include <stdio.h>
#include <stdlib.h>
#include "readcmd.h"
#include <stdbool.h>
#include <string.h>
#include <list.h>

void main(*char arg) {
    int Max = atoi(&arg);

    int i = 2;
    bool premier = true;

    // Liste pour garder les nombres premiers rencontrés
    List *filtres = NULL;
    struct filtres *i;
    Tete = NULL;
    struct filtres *Tete;

    // Création du tube.
    char buffer[100];
    int tube[2];
    if (pipe(tube) == -1) {
        printf("Erreur père");
        exit(1);
    }

    // Création du 1er fils
    int fils = fork();
    if (fils == -1) {
        printf("Erreur fils\n");
        exit(2);
    }

    while(i < argc) {
                            // Processus principal
        if (fils == 0) { /* fils */
            close(tube[1]);
            read(tube[0], buffer, 100);
        else { /* père */
            close(tube[0]);
            if (premier) { // Uniquement le 1er élément renvoyé
                list_append(*filtres, &i); // On ajoute la valeur du filtre à la liste
                premier = false;
            }

            if (i%2 == 0) { // si non multiple de 2
                write(tube[1], i, sizeof(i));

                int fils = fork();
                if (fils == -1) {
                    printf("Erreur fils\n");
                    exit(1);
                }


            }
        wait(NULL);
        }
        }
    i++;
    }
    



    // Affichage, comme on veut tout afficher à la fin.
    for (i , i< sizeof(filtres), i++) {
        printf("%i: %d ", i, liste[i]);
    }

}


