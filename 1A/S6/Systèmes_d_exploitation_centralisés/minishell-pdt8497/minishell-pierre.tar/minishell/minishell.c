#include <stdio.h>
#include <stdlib.h>
#include "readcmd.h"
#include <stdbool.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>

// Ajout des autres programmes (TPs 4 & 5)
// Etape 19 tp 5


/**
#include "copier.c"
#include "tube1.c"
#include "tube2.c"
#include "tube3.c"
#include "tube4.c"
#include "tube5.c"
*/


void traitement(int signal) {
    pid_t pid = waitpid(-1, NULL, WNOHANG);
    printf("Le processus %d est terminé.\n", pid);

    // Etape 13.2 ignorer SIGSTP et SIGINT
//    signal(SIGINT, SIG_IGN); // Ignorer SIGINT
//    signal(SIGTSTP, SIG_IGN); // Ignorer SIGTSTP



    // Etape 13.3: masquer
    sigset_t masque;
    sigemptyset(&masque);
    // Ajouter SIGINT et SIGTSTP au masque
    sigaddset(&masque, SIGINT);
    sigaddset(&masque, SIGTSTP);
    // Masquer les signaux
    sigprocmask(SIG_BLOCK, &masque, NULL);

}


int main(void) {
    bool fini= false;
    
    // Toujours pas reconnu
    struct sigaction action;
    action.sa_handler = traitement;
    sigemptyset(&action.sa_mask);
    action.sa_flags = SA_RESTART;


        while (!fini) {
        printf("> ");
        struct cmdline *commande= readcmd();

        if (commande == NULL) {
            // commande == NULL -> erreur readcmd()
            perror("erreur lecture commande \n");
            exit(EXIT_FAILURE);

        } else {

            if (commande->err) {
                // commande->err != NULL -> commande->seq == NULL
                printf("erreur saisie de la commande : %s\n", commande->err);
        
            } else {

                /* Pour le moment le programme ne fait qu'afficher les commandes 
                   tapees et les affiche à l'écran. 
                   Cette partie est à modifier pour considérer l'exécution de ces
                   commandes
                */
                int indexseq= 0;
                char **cmd;
                while ((cmd= commande->seq[indexseq])) {
                    if (cmd[0]) {
                        if (strcmp(cmd[0], "exit") == 0) {
                            fini= true;
                            printf("Au revoir ...\n");
                        }
                        else {
                            printf("commande : ");
                            int indexcmd= 0;
                            while (cmd[indexcmd]) {
                                printf("%s ", cmd[indexcmd]);
                                indexcmd++;
                            }
                            printf("\n");
                            // Etape 4
                            pid_t pidFils;
                            switch(pidFils = fork()) {
                                case -1: /*erreur*/
                                    printf("erreur");
                                    break;
                                case 0:
                                    setpgrp(); // Etape 14
                                    if(execv(cmd[0], cmd) == -1) {
                                        exit(EXIT_FAILURE);
                                    }
                                    break;
                                default : /*père*/
                                    //Si à garder en "main"
                                    //printf("%d",pidFils); affiche bien un processus
                                    if (commande->backgrounded == NULL) {
                                        waitpid(pidFils, NULL, 0); //permets d'attendre que le fils ait fini
                                        //pause();  // mets une pause de durée inf
                                    }


                                    int status;
                                    int resultat = waitpid(pidFils, &status, WNOHANG);
                                    if (resultat != 0) { // Dès que change d'état on va voir quel état
                                        if (WIFEXITED(status)) {
                                            printf("Le processus fils %d s'est terminé normalement.\n", pidFils);
                                        } else if (WIFSIGNALED(status)) {
                                            printf("Le processus fils %d a été terminé par SIGCHILD.\n", pidFils);
                                        } else if (WIFSTOPPED(status)) {
                                            printf("Le processus fils %d a été suspendu par SIGSTOP.\n", pidFils);
                                        } else if (WIFCONTINUED(status)) {   
                                            printf("Le processus fils %d a été repris par SIGCONT.\n", pidFils);
                                        }
                                    }
                                   break;
                            }
                        }
                        indexseq++;
                    }
                }
            }
        }
    }
    return EXIT_SUCCESS;
}
