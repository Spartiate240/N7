#include <stdio.h>
#include <stdlib.h>
#include "readcmd.h"
#include <stdbool.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>
// Encore les mêmes includes que minishell

// On choisi comme liste des entiers allant de 1 à N:
#define N 10


void main() {
    pid_t pid;

    // Créer le tube
    int pipefd[2];
    if (pipe(pipefd) == -1) {
        perror("Erreur lors de la création du tube");
        exit(EXIT_FAILURE);
    }

    pid = fork();

    if (pid == -1) {
        perror("Erreur lors de la création du processus fils");
        exit(EXIT_FAILURE);

    } else if (pid > 0) {
        // Ecrire la série d'entiers dans le tube
        close(pipefd[0]);
        for (int i = 0; i < N; ++i) {
            write(pipefd[1], &i, sizeof(int));
        }
        close(pipefd[1]);

        pause();

        // Terminer le processus parent
        exit(0);
    } else {
        close(pipefd[1]);
        int value;
        while (read(pipefd[0], &value, sizeof(int)) > 0) {
            printf("Entier: %d\n", value);
        }
    }
    printf("Sortie de boucle\n");
    close(pipefd[0]);
    exit(0);

    return;
}