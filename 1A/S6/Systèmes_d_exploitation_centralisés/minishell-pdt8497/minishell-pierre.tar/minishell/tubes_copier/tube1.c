#include <stdio.h>
#include <stdlib.h>
#include "readcmd.h"
#include <stdbool.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>
// Encore les mêmes includes que minishell


void main() {
    pid_t pid;
    pid = fork(); // Création fils
    int entier = 1; // Entier arbitraire choisi à 1
    
    int pipefd[2];
    
    // Si erreur
    if (pipe(pipefd) == -1) {
        perror("Erreur lors de la création du tube");
        return;
    }
    if (pid == -1) {
        perror("Erreur lors de la création du processus fils");
        exit(EXIT_FAILURE);
    } else if (pid > 0) {

        // Ecrire dans le tube
        close(pipefd[0]); 
        write(pipefd[1], &entier, sizeof(int));
        close(pipefd[1]);

        wait(NULL);
    } 
    
    // Lire dans le tube
    close(pipefd[1]);
    int nb_lu;
    read(pipefd[0], nb_lu, sizeof(int));
    printf("Entier reçu: %s\n", nb_lu);
    close(pipefd[0]);
    return;
}
