#include <stdio.h>
#include <stdlib.h>
#include "readcmd.h"
#include <stdbool.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>
// Encore les mêmes includes que minishell
#define N 10
#define Taille_Tampon (N*sizeof(int))

//On faut le choix d
int main(int signal_ignorer) {
    int tableau[N];
    int pipefd[2];
    pid_t pid;

    // Création du tableau valeurs choisies arbitrairement
    // Pour les changer soit modifier la façon de les affecter,
    // Soit les valeurs afféctées.
    for (int i = 0; i < N; i++) {
        tableau[i] = i + 1;
    }

    // Création du tube
    if (pipe(pipefd) == -1) {
        perror("Erreur lors de la création du tube");
        exit(EXIT_FAILURE);
    }

    pid = fork();
    if (pid == -1) {
        perror("Erreur lors de la création du processus fils");
        exit(EXIT_FAILURE);
    } else if (pid > 0) {
        for (int i =0; i< N; i ++) {
            ssize_t ecrit = write(pipefd[1], tableau, Taille_Tampon);
            printf("Octets écrits: %zd\n", ecrit);
            sleep(1);
        }
    } else {
        signal(signal_ignorer, SIG_IGN);

        pause();

        char tampon[Taille_Tampon];
        ssize_t lu = read(pipefd[0], tampon, Taille_Tampon);
        printf("Octets lus: %zd\n", lu);

        exit(0);
    }

    return Taille_Tampon;
}