#include <stdio.h>
#include <stdlib.h>
#include "readcmd.h"
#include <stdbool.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>
// Les mêmes includes que dans le fichier minishell


#define BUFSIZE 1024


void copier(const char *FIchier_source, const char *Fichier_dest) {
    FILE *srcFile = fopen(FIchier_source, "r");
    FILE *dstFile = fopen(Fichier_dest, "w"); // Créé le fichier s'il existe pas.
    

    // Message d'erreur si jamais il y a un fchier non conforme.
    if (!srcFile) {
        perror("Erreur lors de l'ouverture des fichiers");
        return;
    }

    // Copier le fichier, caractère par caractère
    char buffer[BUFSIZE];
    size_t bytesRead;
    while ((bytesRead = fread(buffer, sizeof(char), BUFSIZE, srcFile)) > 0) {
        fwrite(buffer, sizeof(char), bytesRead, dstFile);
    }

    fclose(srcFile);
    fclose(dstFile);
}